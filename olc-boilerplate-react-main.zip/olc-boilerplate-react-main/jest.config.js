export const preset = 'vite-jest';
export const setupFilesAfterEnv = ['<rootDir>/src/setupTests.js'];
