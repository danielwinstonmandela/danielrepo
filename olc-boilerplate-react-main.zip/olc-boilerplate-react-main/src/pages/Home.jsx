const Home= () => {
  return <div className="text-red-500">Welcome to the Home!</div>
}

export default Home
